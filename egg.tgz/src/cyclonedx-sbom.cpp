// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "cyclonedx sbom");
  std::fflush(stdout);
  return lionss_run_workload("cyclonedx-sbom");
}
