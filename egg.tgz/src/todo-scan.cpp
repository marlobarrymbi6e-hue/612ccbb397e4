// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("todo scan"); }
int main(){
  announce();
  return lionss_run_workload("todo-scan");
}
