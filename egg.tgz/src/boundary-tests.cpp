// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("boundary tests\n", stdout);
  return lionss_run_workload("boundary-tests");
}
