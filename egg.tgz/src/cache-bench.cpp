// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cache bench"); }
int main(){
  announce();
  return lionss_run_workload("cache-bench");
}
