// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("in source guard\n", stdout);
  return lionss_run_workload("in-source-guard");
}
