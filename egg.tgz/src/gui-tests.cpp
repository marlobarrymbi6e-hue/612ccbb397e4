// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gui tests"); }
int main(){
  announce();
  return lionss_run_workload("gui-tests");
}
