// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("reuse lint"); }
int main(){
  announce();
  return lionss_run_workload("reuse-lint");
}
